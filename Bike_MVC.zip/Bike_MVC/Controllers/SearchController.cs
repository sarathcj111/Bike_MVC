﻿using Bike_MVC.Models;
using Bike_MVC.Repository.Interface;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO.Enumeration;
using System.Linq;

namespace Bike_MVC.Controllers
{
    public class SearchController : Controller
    {
        private readonly IBikeRepository _IBikeRepository;
        private readonly ICompanyRepository _ICompanyRepository;
        public SearchController(IBikeRepository iBikeRepository, ICompanyRepository  iCompanyRepository)
        {
            _IBikeRepository = iBikeRepository;
            _ICompanyRepository = iCompanyRepository;

        }
        public IActionResult Index()
        {
            var objSearchModel = new SearchModel();
            objSearchModel.Bikes = _IBikeRepository.GetAllBikes();  //GetAllBikes() is declared in BikeRepository only for this controller.
            objSearchModel.Companys = _ICompanyRepository.GetAllCompany();  // ,,
            ViewBag.SearchListItem = objSearchModel.Companys;
            return View(objSearchModel);
        }

        public IActionResult SearchByCompanyId(string searchString)
        {
            if (searchString == null)
            {
                TempData["msg"] = "<script>alert('No company selected');</script>";
                return RedirectToAction("Index");
            }
            var objSearchModel = new SearchModel();
            objSearchModel.SearchString = null;
            var bikes = _IBikeRepository.SearchBikeByCompany(searchString);
            var company = _ICompanyRepository.SearchCompany(Convert.ToInt32(searchString));
            //objSearchModel.Bikes = new List<BikeModel>();
            objSearchModel.Bikes = bikes.ToList();
            objSearchModel.Companys = new List<CompanyModel>();
            objSearchModel.Companys.Add(company);
            ViewBag.SearchListItem = _ICompanyRepository.GetAllCompany();
            return View("Index", objSearchModel);
        }
        public IActionResult SearchByBikeId(string searchString)
        {
            if (searchString == null)
            {
                TempData["msg"] = "<script>alert('No search Input');</script>";
                return RedirectToAction("Index");
            }
            var objSearchModel = new SearchModel();
            objSearchModel.SearchString = null;
            var bikes = _IBikeRepository.GetAllBikes().Where(x => x.Id == Convert.ToInt32(searchString));
            var companys = _ICompanyRepository.GetAllCompany().Where(z => z.Name == (bikes.ToList().Count > 0 ? bikes.ToList()[0].Company : null));
            //objSearchModel.Bikes = new List<BikeModel>();
            objSearchModel.Bikes = bikes.ToList();
            objSearchModel.Companys = new List<CompanyModel>();
            objSearchModel.Companys = companys.ToList();
            if (objSearchModel.Bikes.Count == 0 && objSearchModel.Companys.Count == 0)
            {
                TempData["msg"] = "<script>alert('No search Data Found');</script>";
                return RedirectToAction("Index");
            }
            ViewBag.SearchListItem = _ICompanyRepository.GetAllCompany();
            return View("Index", objSearchModel);
        }

        public IActionResult SearchByCompanyPattern(string searchString)
        {
            if (searchString == null)
            {
                TempData["msg"] = "<script>alert('No search Input');</script>";
                return RedirectToAction("Index");
            }
            var objSearchModel = new SearchModel();
            objSearchModel.SearchString = null;
            var bikes = _IBikeRepository.GetAllBikes().Where(s => FileSystemName.MatchesSimpleExpression($"*{searchString}*", s.Company));
            var companys = _ICompanyRepository.GetAllCompany().Where(s => FileSystemName.MatchesSimpleExpression($"*{searchString}*", s.Name));
            //objSearchModel.Bikes = new List<BikeModel>();
            objSearchModel.Bikes = bikes.ToList();
            objSearchModel.Companys = new List<CompanyModel>();
            objSearchModel.Companys = companys.ToList();
            if (objSearchModel.Bikes.Count == 0 && objSearchModel.Companys.Count == 0)
            {
                TempData["msg"] = "<script>alert('No search Data Found');</script>";
                return RedirectToAction("Index");
            }
            ViewBag.SearchListItem = _ICompanyRepository.GetAllCompany();
            return View("Index", objSearchModel);
        }
    }
}
