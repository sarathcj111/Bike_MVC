﻿using Bike_MVC.Helper;
using Bike_MVC.Models;
using Bike_MVC.Repository.Interface;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO.Enumeration;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Bike_MVC.Repository
{
        public class BikeRepository : IBikeRepository
        {
            private readonly IConfiguration _config;
           // private HelperClass _helper;
            public BikeRepository(IConfiguration config)
            {
                _config = config;
               // _helper = new HelperClass();
            }

        private List<BikeModel> bikeList = new List<BikeModel>();     // GenerateBikeList is declared here only for doing search method
        private List<BikeModel> GenerateBikeList()
        {

            for (var i = 0; i <= 100; i++)
            {
                if (_config.GetValue<int>($"Bike{i + 1}:Id") > 0)
                {
                    BikeModel bike = new BikeModel();
                    bike.Id = _config.GetValue<int>($"Bike{i + 1}:Id");
                    bike.Company = _config.GetValue<string>($"Bike{i + 1}:Company");
                    bike.Model = _config.GetValue<string>($"Bike{i + 1}:Model");
                    bike.Price = _config.GetValue<decimal>($"Bike{i + 1}:Price");
                    bikeList.Add(bike);
                }
                else
                    break;
            }
            return bikeList;
        }

        public List<BikeModel> GetAllBikes()       // GetAllBikes() is declared here only for doing search method (used in SearchController)
        {
              GenerateBikeList();
              return bikeList;
          } 
        /*
        
         public List<BikeModel> AddNewBike(BikeModel bike)
         {
             var bikes = GenerateBikeList();
             bike.Id = bikes.Count + 1;
             bikes.Add(bike);
             _helper.AddtoJson(bike);
             return bikes;
         } 
       
            public List<BikeModel> EditBike(BikeModel bike)
            {
                var bikes = GenerateBikeList();
                var objBike = bikes.Find(x => x.Id == bike.Id);
                var companies = new CompanyRepository(_config);
                var companyName = companies.GetAllCompany().Find(x => x.Id == Convert.ToInt32(bike.Company)).Name;
                bike.Company = companyName;
                //objBike.Title = bike.Title;
                //objBike.Genre = bike.Genre;
                //objBike.Price = bike.Price;
                //objBike.Company = bike.Company;
                bikes.Remove(bikes.Find(x => x.Id == bike.Id)); // OR Remove(objBike);
                _helper.RemoveFromJson(bike.Id, "Bike");
                bikes.Add(bike);
                _helper.AddtoJson(bike);

                return bikes;
            }

            public bool DeleteBike(int bikeId, out List<BikeModel> bikes)
            {
                bikes = GenerateBikeList();
                bikes.Remove(bikes.Find(x => x.Id == bikeId));
                var bike = bikes.Find(x => x.Id == bikeId);
                if (bike == null)
                {
                    _helper.RemoveFromJson(bikeId, "ghfjgjhs");
                    return true;
                }
                else
                    return false;
            } */



        //API Method
        //Async task execute only after await
        public async Task<List<BikeModel>> GetAllBikesFromApi()
        {
            List<BikeModel> bikes = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44371");

                var result = await client.GetAsync("WebApiBike/getAllBikes");//("Corresponding controller name as in web app / Route name for that action in web app")

                if (result.IsSuccessStatusCode)
                {
                    bikes = JsonConvert.DeserializeObject<List<BikeModel>>(await result.Content.ReadAsStringAsync());
                }
                else
                {
                    throw new Exception("Server error. try after some time.");
                }
            }
            return bikes;
        }


        public async Task<bool> AddNewBikeAsync(BikeModel bike)
        {
            var bikes = await GetAllBikesFromApi();
            bike.Id = bikes.Count + 1;
            var companies = new CompanyRepository(_config);
            var company = await companies.GetAllCompanyFromApi();
            var CompanyName = company.Find(x => x.Id == Convert.ToInt32(bike.Company)).Name;
            bike.Company = CompanyName;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44371");

                string json = JsonConvert.SerializeObject(bike);

                StringContent httpContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

                var result = await client.PostAsync("WebApiBike/addBike", httpContent); //("Corresponding controller name as in web app / Route name for that action in web app")

                if (result.IsSuccessStatusCode)
                {
                    return true;
                }
                else
                {
                    throw new Exception("Server error try after some time.");
                }
            }
        }

        public async Task<List<BikeModel>> EditBikeAsync(BikeModel bike)
        {
            var companies = new CompanyRepository(_config);
            var company = await companies.GetAllCompanyFromApi();
            var CompanyName = company.Find(x => x.Id == Convert.ToInt32(bike.Company)).Name;
            bike.Company = CompanyName;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44371");

                string json = JsonConvert.SerializeObject(bike);

                StringContent httpContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

                var result = await client.PutAsync("WebApiBike/editBike", httpContent);

                if (result.IsSuccessStatusCode)
                {
                    return JsonConvert.DeserializeObject<List<BikeModel>>(await result.Content.ReadAsStringAsync());
                }
                else
                {
                    throw new Exception("Server error try after some time.");
                }
            }
        }

        public async Task<List<BikeModel>> DeleteBikeAsync(int bikeId)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44371");

                // https://localhost:44329/Test/deleteBook?bookid=5&companyId=1

                var result = await client.DeleteAsync($"WebApiBike/deleteBike?bikeid={bikeId}");

                if (result.IsSuccessStatusCode)
                {
                    return JsonConvert.DeserializeObject<List<BikeModel>>(await result.Content.ReadAsStringAsync());
                }
                else
                {
                    throw new Exception("Server error try after some time.");
                }
            }
        }

        //Search Method
        public BikeModel SearchBike(int bikeId)
        {
            var Bikes = GenerateBikeList();  //It is declared in this repository itself
            var Bike = Bikes.Find(x => x.Id == bikeId);   //general format for searching or filtering with bike ID
            return Bike;
        }

        public IEnumerable<BikeModel> SearchLikeBike(string bike)
        {
            var Bikes = GenerateBikeList();
            var Bike = Bikes.Where(s => s.Model.Contains(bike));  //general format for Like searching or filtering using bike name
            return Bike;
        }

        public IEnumerable<BikeModel> SearchLikePatternBike(string pattern)
        {
            var Bikes = GenerateBikeList();
            var Bike = Bikes.Where(s => FileSystemName.MatchesSimpleExpression(pattern, s.Model));  //general format for pattern searching or filtering using bike name
            return Bike;
        }

        public IEnumerable<BikeModel> SearchBikeByCompany(string bikeCompanyId)  //general format for searching or filtering bikes using company name
        {
            var companies = new CompanyRepository(_config);
            var companyName = companies.GetAllCompany().Find(x => x.Id == Convert.ToInt32(bikeCompanyId)).Name;
            var Bikes = GenerateBikeList();
            var BikeList = Bikes.Where(s => s.Company == companyName);
            return BikeList;
        }

    }
}
