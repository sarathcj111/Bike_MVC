﻿using Bike_MVC.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Bike_MVC.Repository.Interface
{
    public interface ICompanyRepository
    {
        /* List<CompanyModel> AddNewCompany(CompanyModel company);
         List<CompanyModel> GetAllCompany();
         List<CompanyModel> EditCompany(CompanyModel company);
         bool DeleteCompany(int companyId, out List<CompanyModel> companys);*/

        Task<List<CompanyModel>> GetAllCompanyFromApi(); 
        Task<bool> AddNewCompanyAsync(CompanyModel company);
        Task<List<CompanyModel>> EditCompanyAsync(CompanyModel company);
        Task<List<CompanyModel>> DeleteCompanyAsync(int companyId);

        //Search
        List<CompanyModel> GetAllCompany();
        CompanyModel SearchCompany(int CompanyId);
        IEnumerable<CompanyModel> SearchLikeCompany(string company);
        IEnumerable<CompanyModel> SearchLikePatternCompany(string pattern);

    }
}
