﻿using Bike_MVC.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Bike_MVC.Repository.Interface
{
    public interface IBikeRepository
    {
        /*
         List<BikeModel> AddNewBike(BikeModel bike);
         List<BikeModel> GetAllBikes();
         List<BikeModel> EditBike(BikeModel bike);
         bool DeleteBike(int bikeId, out List<BikeModel> bikes);
        */


        //API Method
        Task<List<BikeModel>> GetAllBikesFromApi();
        Task<bool> AddNewBikeAsync(BikeModel bike);
        Task<List<BikeModel>> EditBikeAsync(BikeModel bike);
        Task<List<BikeModel>> DeleteBikeAsync(int bikeId);


        //Search
        List<BikeModel> GetAllBikes(); // For doing search
        BikeModel SearchBike(int bikeId);
        IEnumerable<BikeModel> SearchLikeBike(string bike);
        IEnumerable<BikeModel> SearchLikePatternBike(string pattern);
        IEnumerable<BikeModel> SearchBikeByCompany(string bikeCompanyId);
    }
}
