﻿using Bike_MVC.Helper;
using Bike_MVC.Models;
using Bike_MVC.Repository.Interface;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO.Enumeration;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Bike_MVC.Repository
{
    public class CompanyRepository : ICompanyRepository
    {
        private readonly IConfiguration _config;
        //private HelperClass _helper;
        public CompanyRepository(IConfiguration config)
        {
            _config = config;
          //  _helper = new HelperClass();
        }
        
         private List<CompanyModel> companyList = new List<CompanyModel>();    //GenerateCompanyList() declared here only for doing search method
        private List<CompanyModel> GenerateCompanyList()
         {
             for (var i = 0; i <= 100; i++)
             {
                 if (_config.GetValue<int>($"Company{i + 1}:Id") > 0)
                 {
                     CompanyModel company = new CompanyModel();
                     company.Id = _config.GetValue<int>($"Company{i + 1}:Id");
                     company.Name = _config.GetValue<string>($"Company{i + 1}:Name");
                     company.City = _config.GetValue<string>($"Company{i + 1}:City");
                     companyList.Add(company);
                 }
                 else
                 {
                     break;
                 }
             }
             return companyList;
         }

        public List<CompanyModel> GetAllCompany()   // GetAllCompany() is declared here only for doing search method (used in SearchController)
        {
            return GenerateCompanyList();
        }

        /*
         public List<CompanyModel> AddNewCompany(CompanyModel company)
         {
             var companys = GenerateCompanyList();
             company.Id = companys.Count + 1;
             companys.Add(company);
             _helper.AddtoJson(company);
             return companys;
         }

         public List<CompanyModel> EditCompany(CompanyModel company)
         {
             var companys = GenerateCompanyList();
             var objcompany = companys.Find(x => x.Id == company.Id);
             companys.Remove(objcompany);
             _helper.RemoveFromJson(company.Id, "Company");
             companys.Add(company);
             _helper.AddtoJson(company);
             return companys;
         }

         public bool DeleteCompany(int companyId, out List<CompanyModel> companys)
         {
             companys = GenerateCompanyList();
             companys.Remove(companys.Find(x => x.Id == companyId));
             _helper.RemoveFromJson(companyId, "Company");
             var company = companys.Find(x => x.Id == companyId);
             if(company == null)
             {
                 return true;
             }
             else
             {
                 return false;
             }

         } 
        */

        //API Method
        public async Task<List<CompanyModel>> GetAllCompanyFromApi() 
        {
            List<CompanyModel> companys = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44371");

                var result = await client.GetAsync("WebApiCompany/getAllCompany");//("Corresponding controller name as in web app / Route name for that action in web app")

                if (result.IsSuccessStatusCode)
                {
                    companys = JsonConvert.DeserializeObject<List<CompanyModel>>(await result.Content.ReadAsStringAsync());
                }
                else
                {
                    throw new Exception("Server error. try after some time.");
                }
            }
            return companys;
        }

        public async Task<bool> AddNewCompanyAsync(CompanyModel company)
        {
            var companys = await GetAllCompanyFromApi();
            company.Id = companys.Count + 1;
           /* var companies = new CompanyRepository(_config);
            var companyName = companies.GetAllCompanyFromApi().Find(x => x.Id == Convert.ToInt32(bike.Company)).Name;
            bike.Company = companyName;*/

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44371");

                string json = JsonConvert.SerializeObject(company);

                StringContent httpContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

                var result = await client.PostAsync("WebApiCompany/addCompany", httpContent); //("Corresponding controller name as in web app / Route name for that action in web app")

                if (result.IsSuccessStatusCode)
                {
                    return true;
                }
                else
                {
                    throw new Exception("Server error try after some time.");
                }
            }
        }

        public async Task<List<CompanyModel>> EditCompanyAsync(CompanyModel company)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44371");

                string json = JsonConvert.SerializeObject(company);

                StringContent httpContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

                var result = await client.PutAsync("WebApiCompany/editCompany", httpContent);

                if (result.IsSuccessStatusCode)
                {
                    return JsonConvert.DeserializeObject<List<CompanyModel>>(await result.Content.ReadAsStringAsync());
                }
                else
                {
                    throw new Exception("Server error try after some time.");
                }
            }
        }

        public async Task<List<CompanyModel>> DeleteCompanyAsync(int companyId)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44371");

                // https://localhost:44329/WebApiCompany/deleteBook?bookid=5&companyId=1

                var result = await client.DeleteAsync($"WebApiCompany/deleteCompany?companyid={companyId}");

                if (result.IsSuccessStatusCode)
                {
                    return JsonConvert.DeserializeObject<List<CompanyModel>>(await result.Content.ReadAsStringAsync());
                }
                else
                {
                    throw new Exception("Server error try after some time.");
                }
            }
        }

        //Search Method
        public CompanyModel SearchCompany(int CompanyId)
        {
            var Companys = GenerateCompanyList();
            var company = Companys.Find(x => x.Id == CompanyId);
            return company;
        }

        public IEnumerable<CompanyModel> SearchLikeCompany(string company)
        {
            var Companys = GenerateCompanyList();
            var Company = Companys.Where(s => s.Name.Contains(company));
            return Companys;
        }

        public IEnumerable<CompanyModel> SearchLikePatternCompany(string pattern)
        {
            var Companys = GenerateCompanyList();
            var Company = Companys.Where(s => FileSystemName.MatchesSimpleExpression(pattern, s.Name));
            return Company;
        }
    }
}
