﻿using System.ComponentModel.DataAnnotations;

namespace Bike_MVC.Models
{
    public class LoginViewModel
    {
        public string Username { get; set; }

        [DataType(DataType.Password)]   //Not to view password as letters instead to display it as dots
        public string Password { get; set; }
    }
}
