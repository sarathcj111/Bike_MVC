﻿using System.Collections.Generic;

namespace Bike_MVC.Models
{
    public class SearchModel
    {
        public List<BikeModel> Bikes { get; set; }
        public List<CompanyModel> Companys { get; set; }
        public string SearchString { get; set; }
    }
}
// We are making Search method for both Bike & Company therefore calling both models here.