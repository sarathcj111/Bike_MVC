﻿using Bike_MVC.ActionFilter;
using Bike_MVC.Models;
using Bike_MVC.Repository.Interface;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;

using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using static Bike_MVC.ActionFilter.CustomFiter;

namespace Bike_MVC.Controllers
{
    [CustomFiter()]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IBikeRepository _IBikeRepository;
        private readonly ICompanyRepository _ICompanyRepository;
        public HomeController(ILogger<HomeController> logger, IBikeRepository iBikeRepository, ICompanyRepository iCompanyRepository)
        {
            _logger = logger;
            _IBikeRepository = iBikeRepository;
            _ICompanyRepository = iCompanyRepository;
        }
        /*
          public IActionResult Index() //Index-->cshtml file name
          {
              var bikes = _IBikeRepository.GetAllBikes();                    //GetAllBikes() fn from BikeRepository is called
              return View(bikes);
          }

          public IActionResult AddBike(BikeModel bike) 
          {
              var bikes = _IBikeRepository.AddNewBike(bike);                 //AddNewBike() method from BikeRepository is called
              return View("Index", bikes);                                  // The value in bikes will be viewed via index
          }
          public IActionResult OpenAddBikePage()
          {
              var companies = _ICompanyRepository.GetAllCompany();
              ViewBag.ListItem = companies;
              return View("AddBike");                                      // The AddBike view will be viewwd 
          }

          public IActionResult EditBike(BikeModel bike)
          {
              var bikeList = _IBikeRepository.EditBike(bike);
              return View("Index", bikeList);
          }
          public IActionResult OpenEditBikePage(int bikeId)
          {
              var bikeList = _IBikeRepository.GetAllBikes();
              var bike = bikeList.Find(x => x.Id == bikeId);
              var companies = _ICompanyRepository.GetAllCompany();
              ViewBag.ListItem = companies;
              return View("EditBike", bike);
          }

          public IActionResult DeleteBike(int bikeId)
          {
              var isbike = _IBikeRepository.DeleteBike(bikeId, out List<BikeModel> bikes);
              return View("Index", bikes);
          }

          public IActionResult Privacy()
          {
              return View();
          }

          [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
          public IActionResult Error()
          {
              return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
          }
        */


        //API Method
        public async Task<IActionResult> Index()
        {
            try
            {
                var bikes = await _IBikeRepository.GetAllBikesFromApi();   // //GetAllBikesFromApi() fn from BikeRepository is called
                return View(bikes);
            }
            catch (Exception ex)
            {
                return View("Error", new ErrorViewModel { RequestId = ex.Message ?? HttpContext.TraceIdentifier });
            }
        }

        public async Task<IActionResult> AddBike(BikeModel bike)
        {
            try
            {
                var isbikes = await _IBikeRepository.AddNewBikeAsync(bike);
                if (isbikes)
                {
                    var bikes = await _IBikeRepository.GetAllBikesFromApi();
                    return View("Index", bikes);  // // The value in bikes will be viewed via index
                }
                else
                {
                    return View("Error", new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
                }
            }
            catch (Exception ex)
            {
                return View("Error", new ErrorViewModel { RequestId = ex.Message ?? HttpContext.TraceIdentifier });
            }
        }
        public async Task<IActionResult>  OpenAddBikePage()
        {
            var companies = await _ICompanyRepository.GetAllCompanyFromApi();
            ViewBag.ListItem = companies;
            return View("AddBike");
        }

        public async Task<IActionResult> EditBike(BikeModel bike)
        {
            try
            {
                var bikes = await _IBikeRepository.EditBikeAsync(bike);
                return View("Index", bikes);
            }
            catch (Exception ex)
            {
                return View("Error", new ErrorViewModel { RequestId = ex.Message ?? HttpContext.TraceIdentifier });
            }
        }
        public async Task<IActionResult> OpenEditBikePage(int bikeId)
        {
            var bikeList = await _IBikeRepository.GetAllBikesFromApi();
            var bike = bikeList.Find(x => x.Id == bikeId);
            var companies = await _ICompanyRepository.GetAllCompanyFromApi();
            ViewBag.ListItem = companies;
            return View("EditBike", bike);
        }
        public async Task<IActionResult> DeleteBike(int bikeId)
        {
            try
            {
                var bikes=await _IBikeRepository.DeleteBikeAsync(bikeId);
                return View("Index", bikes);
            }
            catch (Exception ex)
            {
                return View("Error", new ErrorViewModel { RequestId = ex.Message ?? HttpContext.TraceIdentifier });
            }
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
    
