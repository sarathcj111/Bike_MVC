﻿using Bike_MVC.ActionFilter;
using Bike_MVC.Models;
using Bike_MVC.Repository.Interface;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;


namespace Bike_MVC.Controllers
{
    [CustomFiter]
    public class CompanyController : Controller
    {
        private readonly ILogger<CompanyController> _logger;
        private readonly ICompanyRepository _ICompanyRepository;
        public CompanyController(ILogger<CompanyController> logger, ICompanyRepository iCompanyRepository)
        {
            _logger = logger;
            _ICompanyRepository = iCompanyRepository;
        }
        /*
         public IActionResult Index()
         {
             var companys = _ICompanyRepository.GetAllCompany();
             return View(companys);
         }

         public IActionResult AddCompany(CompanyModel company)
         {
             var companys = _ICompanyRepository.AddNewCompany(company);
             return View("Index", companys);
         }
         public IActionResult OpenAddCompanyPage()
         {
             List<SelectListItem> Cities = new List<SelectListItem>()
             {
                 new SelectListItem() { Value="Kolkata", Text="Kolkata" },
                 new SelectListItem() { Value="Chennai", Text="Chennai" },
                 new SelectListItem() { Value="Banglore", Text="Banglore" },
                 new SelectListItem() { Value="Delhi", Text="Delhi" }
             };
             ViewBag.Cities = Cities;
             return View("AddCompany");
         }

         public IActionResult EditCompany(CompanyModel company)
         {
             var companyList = _ICompanyRepository.EditCompany(company);
             return View("Index", companyList);
         }
         public IActionResult OpenEditCompanyPage(int companyId)
         {
             var companyList = _ICompanyRepository.GetAllCompany(); //companyList is just a variable and we can use anything instead
             var company = companyList.Find(x => x.Id == companyId);
             List<SelectListItem> Cities = new List<SelectListItem>()
             {
                 new SelectListItem() { Value="Kolkata", Text="Kolkata" },
                 new SelectListItem() { Value="Chennai", Text="Chennai" },
                 new SelectListItem() { Value="Banglore", Text="Banglore" },
                 new SelectListItem() { Value="Delhi", Text="Delhi" }
             };
             ViewBag.Cities = Cities;
             return View("EditCompany", company);
         }

         public IActionResult DeleteCompany(int companyId)
         {
             var objcompanys = _ICompanyRepository.DeleteCompany(companyId, out List<CompanyModel> companys);
             return View("Index", companys);
         }

         public IActionResult Privacy()
         {
             return View();
         }

         [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
         public IActionResult Error()
         {
             return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
         }
        */

        //API Method

        public async Task<IActionResult> Index()
        {
            try
            {
                var companys = await _ICompanyRepository.GetAllCompanyFromApi();   // GetAllBikesFromApi() fn from BikeRepository is called
                return View(companys);
            }
            catch (Exception ex)
            {
                return View("Error", new ErrorViewModel { RequestId = ex.Message ?? HttpContext.TraceIdentifier });
            }
        }

        public async Task<IActionResult> AddCompany(CompanyModel company)
        {
            try
            {
                var iscompanys = await _ICompanyRepository.AddNewCompanyAsync(company);
                if (iscompanys)
                {
                    var companys = await _ICompanyRepository.GetAllCompanyFromApi();
                    return View("Index", companys);  // The value in bikes will be viewed via index
                }
                else
                {
                    return View("Error", new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
                }
            }
            catch (Exception ex)
            {
                return View("Error", new ErrorViewModel { RequestId = ex.Message ?? HttpContext.TraceIdentifier });
            }
        }
        public IActionResult OpenAddCompanyPage()
        {
            List<SelectListItem> Cities = new List<SelectListItem>()
            {
                new SelectListItem() { Value="Kolkata", Text="Kolkata" },
                new SelectListItem() { Value="Chennai", Text="Chennai" },
                new SelectListItem() { Value="Banglore", Text="Banglore" },
                new SelectListItem() { Value="Delhi", Text="Delhi" }
            };

            ViewBag.CityList = Cities;
            return View("AddCompany");
        }

        public async Task<IActionResult> EditCompany(CompanyModel company)
        {
            try
            {
                var companys = await _ICompanyRepository.EditCompanyAsync(company);   // GetAllBikesFromApi() fn from BikeRepository is called
                return View("Index", companys);
            }
            catch (Exception ex)
            {
                return View("Error", new ErrorViewModel { RequestId = ex.Message ?? HttpContext.TraceIdentifier });
            }
        }
        public IActionResult OpenEditCompanyPage(int companyId)
        {
            var company = _ICompanyRepository.SearchCompany(companyId);
            var companyLike = _ICompanyRepository.SearchLikeCompany("com");
            var companyPattern = _ICompanyRepository.SearchLikeCompany("com*");

            List<SelectListItem> Cities = new List<SelectListItem>()
            {
                new SelectListItem() { Value="Kolkata", Text="Kolkata" },
                new SelectListItem() { Value="Chennai", Text="Chennai" },
                new SelectListItem() { Value="Banglore", Text="Banglore" },
                new SelectListItem() { Value="Delhi", Text="Delhi" }
            };

            ViewBag.Cities = Cities;

            return View("EditCompany", company);
        }


        public async Task<IActionResult> DeleteCompany(int companyId)
        {
            try
            {
                var companys = await _ICompanyRepository.DeleteCompanyAsync(companyId);   // GetAllBikesFromApi() fn from BikeRepository is called
                return View("Index", companys);
            }
            catch (Exception ex)
            {
                return View("Error", new ErrorViewModel { RequestId = ex.Message ?? HttpContext.TraceIdentifier });
            }
        }
    }
}
